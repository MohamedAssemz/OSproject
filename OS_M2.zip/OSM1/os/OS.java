

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class OS {
	    boolean flag2=false;
	    Process[] resource;
        Queue<Process> [] Blocked;
        Queue<Process> readyQueue;
        ArrayList<Object[]> disk;
       int time;
       Process a,b,c;
       String p1,p2,p3;
       int tm;
       String p1Entry;
       String p2Entry;
       String p3Entry;
       boolean flaga=false;
       boolean flagb=false;
       boolean flagc=false;
       Memory memory;
     public OS(String s1,String s2,String s3,int tm) {
    	 memory = new Memory();
    	 disk = new ArrayList<Object[]>();
    	 Scanner j = new Scanner(System.in);
    	 System.out.println("please Enter the time that you want p1 to enter in:");
    	 p1Entry = j.nextLine();
    	 System.out.println("please Enter the time that you want p2 to enter in:");
    	 p2Entry = j.nextLine();
    	 System.out.println("please Enter the time that you want p3 to enter in:");
    	 p3Entry = j.nextLine();
    	 this.tm=tm;
    	 resource = new Process[3];
    	 Blocked = new Queue[4];
    	 for(int i=0;i<Blocked.length;i++) {
    	 Blocked[i] = new LinkedList<Process>();
    	 }
    	 readyQueue=new LinkedList<Process>();
    	 time =0;
    	 this.p1 = s1;
    	 this.p2 = s2;
    	 this.p3 = s3;
    	 while(time<25) {
    		 System.out.println("Clock Cycle: " + time);
    		 if ( time == Integer.parseInt(p2Entry) ) {
    			 b = new Process (p2,2,this);
    			 assignMemory(b);
    			 readyQueue.add(b);
    		 }else if ( time == Integer.parseInt(p3Entry)) {
    			 c= new Process (p3,3,this);
    			 assignMemory(c);
    			 readyQueue.add(c);
    		 }else if(time==Integer.parseInt(p1Entry)){
    			 a=new Process(this.p1,1,this);
    			 assignMemory(a);
    	    	 readyQueue.add(a);
    		 }
    		 
    		 
    	 try {
			scheduler();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	 memory.print();
    	 time++;
    	
    	 
     }
    	 
 		 //Process b=new Process(p2,2);
 		 //Process c=new Process(p3,3);
     }
     public  void semWait(String res,Process p) {
    	 switch(res){
    	 
    	 case "userInput":
    		 if(resource[0]!=null) {
    			Blocked[0].add(p);
    			Blocked[3].add(p);
    			readyQueue.remove(p);
    			p.pcb.processState=State.BLOCKED;
      		     System.out.print("BlockedQueue: ");
				  print(1);
				  System.out.print("ReadyQueue ");
				  print(2);
    			
    	     }else {
    	    	 resource[0]=p;
    	    	
    	     }
    		 break;
    		 
    	 case "userOutput":
    		 if(resource[1]!=null) {
     			Blocked[1].add(p);
     			Blocked[3].add(p);
    			readyQueue.remove(p);
     			p.pcb.processState=State.BLOCKED;
     			System.out.print("BlockedQueue: ");
     			print(1);
     			System.out.print("ReadyQueue ");
     			print(2);
     			
     	     }else {
     	    	 resource[1]=p;
     	    	
     	     }
     		 break;
     		 
    	 case "file":
    		 if(resource[2]!=null) {
      			Blocked[2].add(p);
      			Blocked[3].add(p);
    			readyQueue.remove(p);
    			p.pcb.processState=State.BLOCKED;
      			System.out.print("BlockedQueue: ");
				  print(1);
				  System.out.print("ReadyQueue ");
				  print(2);
      			
      	     }else {
      	    	 resource[2]=p;
      	    	
      	     }
      		 break;
    		 
    	 }
     }

     
     public  void semSignal(String res,Process p) {
    	 switch(res) {
    	 case "userInput":
    		 
    		  if(!resource[0].equals(p)) return;
    		  if(!Blocked[0].isEmpty()) {
    			 resource[0]= Blocked[0].poll();
    			 Blocked[3].remove(resource[0]);
    			 readyQueue.add(resource[0]);
    			 resource[0].pcb.processState=State.READY;
    		  }else {
    			  resource[0]=null;
    		  }
    		  break;
    	 case "userOutput":
    		
   		     if(!resource[1].equals(p)) return;
   		     if(!Blocked[1].isEmpty()) {
   		    	 resource[1]= Blocked[1].poll();
   		    	 Blocked[3].remove(resource[1]);
   		    	 readyQueue.add(resource[1]);
   		    	 resource[1].pcb.processState=State.READY;
   		     }else {
   		    	 resource[1]=null;
   		     }
   		     break;
    	 case "file":
    		
   		  if(!resource[2].equals(p)) return;
   		  if(!Blocked[2].isEmpty()) {
   			 resource[2]= Blocked[2].poll();
   			 Blocked[3].remove(resource[2]);
   			 readyQueue.add(resource[2]);
   			 resource[2].pcb.processState=State.READY;
   		  }else {
   			  resource[2]=null;
   		  }
   		  break;
    	 
    	 
    	 
    	 }
     }
     
     public void scheduler() throws IOException {
    	 
    	 while(!readyQueue.isEmpty()) {
    		 
    		 if(a!=null) {
    		 for(int i=1;i<=tm;i++) {
    		   if((!a.state.equals(State.FINISHED)) && (a.state.equals(State.READY)) && (!readyQueue.isEmpty()) && (a.equals(readyQueue.element()))) {
    			  if(flaga==false) {
    				  System.out.print("BlockedQueue: ");
    				  print(1);
    				  System.out.print("ReadyQueue ");
    				  print(2);
    				  flaga=true;
    			  }
    			  if(!a.inMemory()){
            		  memorySwap(a);
            	  }
    			 a.exectute();
    			 memory.print();
    			 time++;
    			 System.out.println("Clock Cycle: " + time);
    			 if ( time == Integer.parseInt(p2Entry) ) {
    				 b = new Process (p2,2,this);
    				 assignMemory(b);
    				 readyQueue.add(b);
    			 }else if ( time == Integer.parseInt(p3Entry)) {
    				 c= new Process (p3,3,this);
    				 assignMemory(c);
    				 readyQueue.add(c);
    			 }else if(time==Integer.parseInt(p1Entry)){
        			 a=new Process(this.p1,1,this);
        			 assignMemory(a);
        	    	 readyQueue.add(a);
        	    	 }
    		 	}else {
    		 		break;
    		 	}
    		   if(i==tm && !readyQueue.isEmpty()) {
             	  readyQueue.add(readyQueue.remove());
             	  flaga=false;
               }
    		 }
    		 
    		 } 
    		 
    		 
           if(b!=null) {
    		 for(int i=1;i<=tm;i++) { 
    		   if((!b.state.equals(State.FINISHED)) && (b.state.equals(State.READY)) && (!readyQueue.isEmpty()) && (b.equals(readyQueue.element()))) {
    			   if(flagb==false) {
    				  System.out.print("BlockedQueue: ");
    				  print(1);
    				  System.out.print("ReadyQueue ");
    				  print(2);
     				  flagb=true;
     			  }
    			   if(!b.inMemory()){
             		  memorySwap(b);
             	  }
    			 b.exectute();
    			 memory.print();
    			 time++;
    			 System.out.println("Clock Cycle: " + time);
    			 if ( time == Integer.parseInt(p2Entry) ) {
    				 b = new Process (p2,2,this);
    				 assignMemory(b);
    				 readyQueue.add(b);
    			 }else if ( time == Integer.parseInt(p3Entry)) {
    				 c= new Process (p3,3,this);
    				 assignMemory(c);
    				 readyQueue.add(c);
    			 }else if(time==Integer.parseInt(p1Entry)){
        			 a=new Process(this.p1,1,this);
        			 assignMemory(a);
        	    	 readyQueue.add(a);
        		 }
    		   }else {
    			   break;
    		   }
    		   if(i==tm && (!readyQueue.isEmpty())) {
             	  readyQueue.add(readyQueue.remove());
             	  flagb=false;
               }
    		}
            
           }
    		 
    		
           
    		 
          if(c!=null) {
            for(int i=1;i<=tm;i++) {
              if((!c.state.equals(State.FINISHED)) && (c.state.equals(State.READY)) && (!readyQueue.isEmpty()) && (c.equals(readyQueue.element()))) {
            	  if(flagc==false) {
            		  
            		  System.out.print("BlockedQueue: ");
    				  print(1);
    				  System.out.print("ReadyQueue ");
    				  print(2);
    				  flagc=true;
    			  }
            	  if(!c.inMemory()){
            		  memorySwap(c);
            	  }
    			 c.exectute();
    			 memory.print();
    			 time++;
    			 System.out.println("Clock Cycle: " + time);
    			 if ( time == Integer.parseInt(p2Entry) ) {
    				 b = new Process (p2,2,this);
    				 assignMemory(b);
    				 readyQueue.add(b);
    			 }else if ( time == Integer.parseInt(p3Entry)) {
    				 c= new Process (p3,3,this);
    				 assignMemory(c);
    				 readyQueue.add(c);
    			 }else if(time==Integer.parseInt(p1Entry)){
        			 a=new Process(this.p1,1,this);
        			 assignMemory(a);
        	    	 readyQueue.add(a);
        		 }
    		   }else {
    			   break;
    		   }
              if(i==tm && !readyQueue.isEmpty()) {
            	  readyQueue.add(readyQueue.remove());
              }
        
            }
        
          }
    		 
          
   			
    		 
          
          flagb=false;
		  flaga=false;
		  flagc=false;
    		 
    		 
    		 
    		 
    	 }
     }
 
     
     
     public void print(int v) {
    	 if(v==1) {
    	 
    	 System.out.print("[ ");
    	 for(int q=0;q<Blocked[3].size();q++) {
    		 Process h=Blocked[3].poll();
    		 Blocked[3].add(h);
    		 System.out.print("Process"+ h.pID+", ");
    	 }
    	 System.out.println(" ]");
    	 }else {
    		 
        	 System.out.print("[ ");
        	 for(int q=0;q<readyQueue.size();q++) {
        		 Process k=readyQueue.poll();
        		 readyQueue.add(k);
        		 System.out.print("Process"+k.pID+", ");
        	 }
        	 System.out.println(" ]");
    	 }
     }
     
     
     public void assignMemory(Process p){
    	 int words = 18;
    	 int lb = memory.allocate();
    	 if (lb == 41){
    		 initialSwap(p);
    		 return;
    	 }
    	 p.pcb.lowerMemoryBound = lb;
		 p.pcb.upperMemoryBound = lb +words-1;
		 p.pcb.pc = lb+7+(11-p.commands.size());
		 memory.mem[lb] = p.pcb.processID;
		 memory.mem[lb+1] = p.pcb.pc;
		 memory.mem[lb+2] = p.pcb.processState;
		 memory.mem[lb+3] = "(lb = " + p.pcb.lowerMemoryBound + " ; ub = " + p.pcb.upperMemoryBound + ")";
		 int j =0;
		 //we start after the first 7 to check if the upperbound is exceeded which means that the process is finished, which we'll handle in execute
		 for (int i = lb+7+(11-p.commands.size()); i<=(p.pcb.upperMemoryBound); i++){
				 memory.mem[i] = p.commands.get(j);
				 j++;
				 if (j>= p.commands.size()){
					 break;
				 }
		 }
		 memory.print();
     }
     
     public void memorySwap (Process p){
    	 int lb1 = memory.allocate();
    	 
    	 Object [] arr = disk.remove(0);
    	 Object [] tmp = new Object[18];
    	 int j=0;
    	 if (lb1 !=41){
    		 int diff = p.pcb.lowerMemoryBound-lb1;
    		 p.pcb.lowerMemoryBound = p.pcb.lowerMemoryBound-diff;
    		 p.pcb.upperMemoryBound = p.pcb.lowerMemoryBound+17;
    		 p.pcb.pc = p.pcb.pc - diff;
    		 for (int i = p.pcb.lowerMemoryBound; i <= p.pcb.upperMemoryBound; i++,j++){
    			 this.memory.mem[i] = arr[j];
    		 }
    		 System.out.println("Process " + p.pcb.processID + " swapped into memory");
    		 memory.print();
    		 return;
    	 }
    	 int lb = p.pcb.lowerMemoryBound;
    	 for (int i = lb; i <= p.pcb.upperMemoryBound; i++,j++){
			 tmp[j] = this.memory.mem[i];
			 this.memory.mem[i] = arr[j];
		 }
    	 this.writeToDisk(tmp);
    	 disk.add(tmp);
		 System.out.println("Process " + p.pcb.processID + " swapped into memory");
		 System.out.println("Process " + (int)tmp[0] + " swapped out of memory into disk");
		 memory.print();
     }
     public void initialSwap (Process p){
    	 
    	 int j = 0;
    	 Object [] tmp;
    	 tmp = new Object[18];
    	 Process p1;
    	 if (this.Blocked[3].isEmpty()){
    		 this.readyQueue.add(readyQueue.poll());
        	 p1 = this.readyQueue.element();
        	 this.readyQueue.add(readyQueue.poll());
    	 }
    	 else {
    		 p1 = this.Blocked[3].element();
    	 }
    	 int lb = p1.pcb.lowerMemoryBound;
    	 for (int i = lb; i <= p1.pcb.upperMemoryBound; i++,j++){
			 tmp[j] = this.memory.mem[i];
		 }
    	 this.writeToDisk(tmp);
		 disk.add(tmp);
		 p.pcb.lowerMemoryBound = lb;
		 p.pcb.upperMemoryBound = lb +17;
		 p.pcb.pc = lb+7+(11-p.commands.size());
		 memory.mem[lb] = p.pcb.processID;
		 memory.mem[lb+1] = p.pcb.pc;
		 memory.mem[lb+2] = p.pcb.processState;
		 memory.mem[lb+3] = "(lb = " + p.pcb.lowerMemoryBound + " ; ub = " + p.pcb.upperMemoryBound + ")";
		 int k =0;
		 for (int i = lb+7+(11-p.commands.size()); i<=(p.pcb.upperMemoryBound); i++){
				 memory.mem[i] = p.commands.get(k);
				 k++;
				 if (k>= p.commands.size()){
					 break;
				 }
		 }
		 System.out.println("Process " + p.pcb.processID + " swapped into memory");
		 System.out.println("Process " + p1.pcb.processID + " swapped out of memory into disk");
		 memory.print();
//    	 if (p.equals(a)){
//    		 b1 = b.pcb.lowerMemoryBound;
//    		 b2 = c.pcb.lowerMemoryBound;
//    		 if (b1>b2){
//    			 tmp = new Object[b.pcb.upperMemoryBound + 1 - b1];
//    			 for (int i = b1; i <= b.pcb.upperMemoryBound; i++){
//    				 tmp[j] = this.memory.mem[i];
//    				 j++;
//    			 }
//    			 disk.add(tmp);
//    		 }else{
//    			 
//    		 }
//    	 }else if (p.equals(b)){
//    		 
//    	 }else{
//    		 
//    	 }
     }
     public void writeToDisk(Object [] proc){
    	 try {
			FileWriter fw = new FileWriter("D:\\Backup_D\\GUC\\Semester_6\\Operating Systems\\Project M1\\Disk.txt");
			String s="";
			for (int i = 0; i<18; i++){
				if (i!=17)
					s += proc[i]+",";
				else
					s += proc[i];
			}
			fw.write(s);
			fw.close();
			//fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
			e.printStackTrace();
		}
     }
     
     public static void main(String [] args) throws IOException {
 		new OS("Program_1.txt","Program_2.txt","Program_3.txt",2);
 		
 	}

}
