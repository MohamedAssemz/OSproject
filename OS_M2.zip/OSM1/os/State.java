

public enum State {
 READY,RUNNING,BLOCKED,FINISHED
}
