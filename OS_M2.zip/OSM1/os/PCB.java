
public class PCB {
	int processID;
	State processState;
	int pc;
	int lowerMemoryBound;
	int upperMemoryBound;
	
	public PCB(int id){
		this.processID=id;
		processState = State.READY;
		pc = 0;
	}
	
	public void print(){
		System.out.print("(pID : " + processID + ", pc : " + pc + ", lb : " + 
	this.lowerMemoryBound + ", ub : " + this.upperMemoryBound + ")");
	}
}
