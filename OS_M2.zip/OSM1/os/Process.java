
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
public class Process {
	
	ArrayList<String> commands;
	HashMap<String,Object> memory;
	String temp;
	String inputTemp;
	int pID;
	State state;
	OS os;
	boolean flag1=false;
	PCB pcb;
	
	
	
	public Process(String program,int pID,OS os){
		  temp="";
		  commands=new ArrayList<String>(); 
		  memory = new HashMap<String,Object>();
		  interpret(program);
		  pcb = new PCB (pID);
		  this.state = pcb.processState;
		  this.pID=pcb.processID;
		  this.os=os;
		  
		     
	}
   

	
	public void interpret(String x) {
    	BufferedReader br;
    	try{	
    		
            br = new BufferedReader(new FileReader("D:/Backup_D/GUC/Semester_6/Operating Systems/Project M1/"+ x));		
 	        String contentLine = br.readLine();
 	        while (contentLine != null) {
 	          if (contentLine.substring(0,6).equals("assign")){
 	        	  String [] prts = contentLine.split(" ");
 	        	  String l1 = (prts.length == 3)? prts[2]: prts[2] + " " + prts[3];
 	        	  String l2 = prts[0] + " " + prts[1];
 	        	  this.commands.add(l1);
 	        	  this.commands.add(l2);
 	        	 contentLine = br.readLine();
 	          }else{
 	        	 this.commands.add(contentLine);
 	 	          contentLine = br.readLine();
 	          }
 	          
 	   }
    } catch (IOException ioe) 
        {
 	   ioe.printStackTrace();
        }
    	
	
}
   

	
	public void exectute() throws IOException {
		System.out.println("Process "+pID+" is currently executing");
		pcb.print();
		System.out.println();
        String[] parts = ((String)this.os.memory.mem[this.pcb.pc]).split(" ");
        if (parts.length != 4) {
        	System.out.println("Instruction: "+((String)this.os.memory.mem[this.pcb.pc]));
        }
      
    	switch(parts[0]) {
    	case "Print":
    		 Print(parts[1]);
    		break;
    	case "assign":	
    		assign(parts[1]);
    		//handle this case as variables should be stored in memory
//    		if (parts.length > 2 && parts[2].equals("readFile")){
//    			System.out.print("Instruction: "+parts[2] + " " + parts[3]);
//      	       readFile(parts[3]);
//      	       String a = parts[0] + " " + parts[1];
//      	       commands.remove(0);
//      	       commands.add(0, a);
//      	       flag1=true;
//      	     return;
//          }else {
//        	  if(flag1) {
//    		   assign(parts[1],temp);
//    		   flag1=false;
//        	  }else {
//        		  assign(parts[1],parts[2]);
//        	  }
//          }
    		   break;
    	case "input":
    		input();
    		break;
    	case "readFile":	
    		readFile(parts[1]);
    		break;
    	case "writeFile":
    		writeFile(parts[1],parts[2]);
    		break;
    	case "printFromTo":
    		printFromTo(parts[1],parts[2]);
    		break;
    	case "semWait":
    		   os.semWait(parts[1],this);
    		   break;
    	case "semSignal":
    		   os.semSignal(parts[1],this);
    		   break;
    	
    	default:
    		
    	
    }
    	
    
    	pcb.pc++;
    	this.os.memory.mem[this.pcb.lowerMemoryBound+1]=this.pcb.pc;
    	this.os.memory.mem[this.pcb.lowerMemoryBound+2]=this.pcb.processState;
    	if(this.pcb.pc > this.pcb.upperMemoryBound || this.os.memory.mem[this.pcb.pc] == null) {
    		  pcb.processState=State.FINISHED;
    		  os.readyQueue.remove();
    		  int lb = this.pcb.lowerMemoryBound;
    		  int ub = this.pcb.upperMemoryBound;
    		  for (int i = lb; i<= ub; i++){
    			  os.memory.mem[i] = null;
    		  }
   			  System.out.print("BlockedQueue: ");
			  os.print(1);
			  System.out.print("ReadyQueue ");
			  os.print(2);
  		      
    		
    	}
    	
    }
   
	public void input(){
		Scanner s = new Scanner(System.in);	
		 System.out.println("Enter a value to Store:");
		   inputTemp = s.nextLine();
		
	}
	
	public void Print(String text){
		
		if(memory.containsKey(text)) {
			  System.out.println(memory.get(text));
			}
			else {
				System.out.println(text+"Not found in memory");
			}
	}
		
  

	
	public void readFile(String f) {
		String file=readFromMemory(f);
		temp="";
		try {
			BufferedReader B = new BufferedReader(new FileReader("D:/Backup_D/GUC/Semester_6/Operating Systems/Project M1/"+file+".txt"));
	         String temps = B.readLine();
			while(temps != null){
				temp+=temps;
				temps = B.readLine();
				}
		}catch(Exception e) {
			System.out.println("File not Found");
		}
	}
	
	

	
	public void writeFile(String x,String y) throws IOException{
		   String a=readFromMemory(x);
		   String z=readFromMemory(y);
		
		
		   try {
	            FileOutputStream fos = new FileOutputStream("D:/Backup_D/GUC/Semester_6/Operating Systems/Project M1/"+a+".txt");
	            fos.write(z.getBytes());
	            fos.flush();
	            fos.close();
	        }
	        catch (IOException e){
	        	File f =new File("D:/Backup_D/GUC/Semester_6/Operating Systems/Project M1/"+a+".txt");   //if it doesn't exist it will be generated automatically
	    		FileWriter w = new FileWriter(f ,true);
	    		PrintWriter p =new PrintWriter(f);
	    		p.println(z);
	    		w.close();
	    		p.close();
	        }
		
	}
	
	

	
	public void assign(String f){
	boolean flag=false;
	boolean flag1=false;
	boolean flag2=false;
	String z;
	if (inputTemp!=null){
		z = inputTemp;
		flag1=true;
	}else{
		z = temp;
		flag2=true;
	}
	  if(memory.containsKey(f)){
          memory.replace(f, z);
          flag=true;
   }
	
	 
	 if(flag==false) {
		 memory.put(f,z);
	 }
	  String x = z;
	  writeToMemory(f,z);
	  System.out.println("The value is: "+x);
	  if (flag2==true){
	  temp = null;
	  }
	  if (flag1==true){
	  inputTemp = null;
	  }
	  
  }
		 
	  public String readFromMemory(String x){
		  int lb = this.pcb.lowerMemoryBound;
		  for (int i = lb+4; i<lb+7; i++){
			  if ((((Variable)this.os.memory.mem[i]).var).equals(x))
				  return ((Variable)this.os.memory.mem[i]).value;
		  }
		  return "Not found";
	  }
	  
	  public void writeToMemory(String x, String y){
		  Variable var1 = new Variable (x,y);
		  int lb = this.pcb.lowerMemoryBound;
		  for (int i = lb+4; i<lb+7; i++){
			  if (this.os.memory.mem[i] == null){
				  this.os.memory.mem[i]= var1;
				  break;
			  }
		  }
	  }
	
	 public  void printFromTo(String x, String y){
		 int start= Integer.parseInt(readFromMemory(x));
		 int end= Integer.parseInt(readFromMemory(y));
	        for(int i = start; i <= end; i++){
	            System.out.println(i);
	        }
	    }
	 
	 public boolean inMemory(){
		 if (this.os.memory.mem[this.pcb.lowerMemoryBound]!=null && (int)this.os.memory.mem[this.pcb.lowerMemoryBound] == this.pcb.processID){
			 return true;
		 }else{
			 return false;
		 }
	 }
	
}
