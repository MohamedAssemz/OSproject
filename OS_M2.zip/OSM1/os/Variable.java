
public class Variable {
	String var;
	String value;
	public Variable (String var, String value){
		this.var = var;
		this.value = value;
	}
	
	public void print(){
		System.out.print("(" + var + ", " + value + ")");
	}
}
