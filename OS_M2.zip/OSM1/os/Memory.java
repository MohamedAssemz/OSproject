
public class Memory {
	Object [] mem;
	public Memory (){
		mem = new Object [40];
	}
	
	public int allocate(){
		int y = 0;
		int lb;
		for (int i = 0; i<40; i++){
			y=0;
			if (mem[i] == null){
				lb = i;
				while(i<40 && mem[i]==null){
					y++;
					i++;
					if (y>=18){
						return lb;
					}
				}
			}
		}
		return 41;
	}
	
	public void print(){
		System.out.print("Memory: [ ");
		for (int i = 0; i<40 ; i++){
			if (mem[i]==null){
				System.out.print( "Empty ,");
			}else if (mem[i] instanceof PCB){
				((PCB)mem[i]).print();
				System.out.print( " ,");
			}else if (mem[i] instanceof Variable ){
				((Variable)mem[i]).print();
				System.out.print( " ,");
			}else {
			
				System.out.print(mem[i] + " ,");
			}
			
		}
		System.out.println( " ]");
	}
}
